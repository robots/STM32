# ancient WinZips can't handle 0-length files
