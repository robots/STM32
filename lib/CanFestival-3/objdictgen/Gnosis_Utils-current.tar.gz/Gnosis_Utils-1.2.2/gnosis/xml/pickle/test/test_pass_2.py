# used for sanity checking the test harness
# a "pass" test by sys.exit(0)

import sys
sys.exit(0)
